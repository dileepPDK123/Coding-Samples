package StepDefinitions;

import cucumber.api.java.en.Given;

public class TagsSteps {

	@Given("^user is on Application HomePage$")
	public void user_is_on_Application_HomePage()  {
	   System.out.println("Hi I am Dummy");
	}
}
