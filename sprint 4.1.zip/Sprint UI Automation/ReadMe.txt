CONTENTS OF THIS FILE
---------------------
 
 * Introduction
 * Pre-requisites
 * Tools Used
 * Procedure for accessing

Introduction:

The Sprints module is present on the Mainspring webpage.
This module creates a new sprint by entering all the valid details in the fields and saving it.

Pre-requisites:

The mainspring which contains the Sprints module should be opened by the authenticated user.
A new Release must be created inorder to fill the release field while creating a new Sprint 
A new Team should be created to fill up the Team field while creating the new sprint
 

Url for Mainspring : https://pratesting.cognizant.com

Frameworks & Tools Used:

			* Java(version JavaSE-1.7)
                        * Selenium Web Driver (Version 3.141.59)
			* Maven (version 3.8.1)
			* TestNG (Version 7.1)
			* Cucumber BDD (Version 1.2.5)

Steps to go to sprint module:

1. Point to menu icon or hamburger icon at the left top. The left navigation pane appears.
2. In the Project/Program list, click the relevant project or program. The Project Details or Program Details page appears.
3. Point to Plan, and then click Sprints module. The Sprints page appears, displaying a list of the created sprints.

To add a New Sprint:

You can add a new sprint by clicking on + button(Add sprint) on the page
And we need to fill all the mandatory fields like name,sprint type, start and end date, release and No.of teams with valid details.
If any mandatory fields are empty or invalid it shows a alert message while saving and describes the type of error.
After entering all the mandatory fields with valid inputs, click on the save button.


Execution of the code:
 Code will be executed through testng.xml file