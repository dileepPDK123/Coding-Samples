package com.sprint.testcases;

import com.ReadExcel.readExcel;
import com.sprint.testData.sprintInvalidData;

import cucumber.api.java.en.Then;

public class sprintInvalidDataTestCases extends sprintInvalidData{
	 
	@Then("^Clear the sprinttype to None$")
	public void clear_the_sprinttype_to_None() {
		invalidsprint();
	}
	

@Then("^Clear the StartDate Text box$")
public void clear_the_StartDate_Text_box(){
	invalidStartDate();
}

@Then("^Clear the EndDate Text box$")
public void clear_the_EndDate_Text_box() {
	invalidEndDate();
}

@Then("^Clear the Release to None$")
public void clear_the_Release_to_None(){
	invalidRelease();
}

@Then("^Clear the No of Teams Teaxt box$")
public void clear_the_No_of_Teams_Teaxt_box() {
	invalidnoofTeams();
}

@Then("^Checking the Name Alert message$")
public void checking_the_Name_Alert_message(){
	nameAssert();
}


@Then("^Checking the Sprint Alert message$")
public void checking_the_Sprint_Alert_message() {
	sprintAssert();
}

@Then("^Checking the StartDate Alert message$")
public void checking_the_StartDate_Alert_message() {
	startDateAssert();
}

@Then("^Checking the EndDate Alert message$")
public void checking_the_EndDate_Alert_message() {
	endDateAssert();
}

@Then("^Checking the Release Alert message$")
public void checking_the_Release_Alert_message(){
	releaseAssert();
}

@Then("^Checking the No of teams Alert message$")
public void checking_the_No_of_teams_Alert_message() {
	noofteamsAssert();
}


@Then("^Enter a decimal value to No on Teams Text box$")
public void enter_a_decimal_value_to_No_on_Teams_Text_box()  {
	try {
		String noofteamSearchData = readExcel.read(1, 7);
		sendKeys("noofTeam_Name", noofteamSearchData);
	} catch (Exception e) {
		e.printStackTrace();
	}
}

@Then("^Checking the invalid No of teams Alert message$")
public void checking_the_invalid_No_of_teams_Alert_message(){
	InvalidnoofteamsAssert();
}


              
}
