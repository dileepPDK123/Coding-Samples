package com.sprint.testcases;

import com.sprint.testData.sprintValidData;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.sprint.baseMethods;

/*
 * testing class by using cucumber
 */
public class sprintValidDataTestcases extends sprintValidData {
	/*
	 * Calling the url method and using @when to execute the test case using
	 * cucumber feature
	 */
	@When("^Opening the url$")
	public static void url_test_cases() throws Exception {
		try {
			url();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the opendefect method and using @Then to execute the test case using
	 * cucumber feature
	 */
	@Then("^Open sprint in the url$")
	public static void defectOpeningtestcases() {
		try {
			openSprint();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^User Navigate to MainSpring webpage$")
	public void user_Navigate_to_MainSpring_webpage() {

		WebDriverWait wait = new WebDriverWait(driver, 240);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='left_menu_icon_overlay']")));
		String workitems = getElement("workitems_Xpath").getText();
		String expected = "My Workitems";
		Assert.assertEquals(expected, workitems);
		System.out.println("User is on the mainspring webpage");
	}

	@Then("^User Navigate to Sprint webpage$")
	public void user_Navigate_to_Sprint_webpage() {
		String actual = getElement("sprintCheck_Xpath").getText();
		String expected = "Sprints";
		Assert.assertEquals(expected, actual);
	}

	/*
	 * Calling the nameTextBox method and using @Then to execute the test case using
	 * cucumber feature
	 */
	@Then("^Enter Data into name textbox$")
	public void nameTextBoxtestcases() throws Exception {
		try {
			nameTextBox();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the descriptionTextBox method and using @Then to execute the test
	 * case using cucumber feature
	 */
	@Then("^Enter Data into description textbox$")
	public void descriptionTextBoxtestcases() {
		try {
			descriptionTextBox();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Select Data from sprint dropdownbox$")
	public void sprintDropDownBoxtestcases() {
		try {
			sprintDropDownBox();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Enter startDate into Date textbox$")
	public void startDatetestcases() {
		try {
			startDate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Enter endDate into Date textbox$")
	public void endDatetestcases() {
		try {
			endDate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Select Data from release dropdownbox$")
	public void releaseDropDownBoxtestcases() {
		try {
			releaseDropDownBox();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Select Data from responsible dropdownbox$")
	public void responsibleDropDownBoxtestcases() {
		try {
			responsibleDropDownBox();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Enter Data into No of Teams Textbox$")
	public void noofTeamstestcases() {
		try {
			no_of_teams();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Enter Data into capacity Textbox$")
	public void capacitytestcases() {
		try {
			capacity();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Select Data from team dropdownbox$")
	public void select_Data_from_team_dropdownbox() {
		try {
			teamsDropDownBox();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Click on Save Button$")
	public void saveButtontestcases() {
		try {
			saveButton();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Click on return button$")
	public void Returntestcases() {
		try {
			Return();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Calling the method and using @Then to execute the test case using cucumber
	 * feature
	 */
	@Then("^Close the browser$")
	public void closetestcases() {
		try {
			close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Switch Frame$")
	public void switch_Frame() {
		switchFrame();
	}

	@Then("^Accept the Alert$")
	public void accept_the_Alert() {
		alertaccept();
	}

	@Then("^Checking Sprint Saved Or not$")
	public void checking_Sprint_Saved_Or_not() {
		 Assert.assertFalse(getElement("save_Id").isEnabled());  
	}

	@Then("^Closing the Browser$")
	public void closing_the_Browser() {
		close();
	}

}
