package com.sprint.testData;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ReadExcel.readExcel;
import com.sprint.baseMethods;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class sprintValidData extends baseMethods {
	/*
	 * method for opening browser and url
	 */
	public static void url() throws Exception {
		try {
			openBrowser();
			openURL("url");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for opening sprint module in the pratesting website
	 */
	public static void sprintOpening() {
		try {
			openSprint();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for name text box
	 */
	public void nameTextBox() throws Exception {
		try {
			String nameSearchData = readExcel.read(1, 0);
			sendKeys("name_Id", nameSearchData);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for description text box
	 */
	public void descriptionTextBox() throws Exception {
		try {

			String desSearchData = readExcel.read(1, 1);
			sendKeys("description_Name", desSearchData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for sprint drop down box
	 */
	public void sprintDropDownBox() {
		try {
			String sprintSearchData = readExcel.read(1, 2);
			dropDown("Sprint_Name", sprintSearchData);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void startDate() {
		try {
			String startSearchData = readExcel.read(1, 3);
			start(startSearchData);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void endDate() {
		try {
			String endSearchData = readExcel.read(1, 4);
			sendKeys("Date_Id", endSearchData);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for release drop down box
	 */
	public void releaseDropDownBox() {
		try {
			String releaseSearchData = readExcel.read(1, 5);
			dropDown("Release_Name", releaseSearchData);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/*
	 * method for responsible drop down box
	 */
	public void responsibleDropDownBox() {
		try {
			String responsibleSearchData = readExcel.read(1, 6);
			dropDown("responsible_Name", responsibleSearchData);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void no_of_teams() {
		try {
			String noofteamSearchData = readExcel.read(1, 7);
			sendKeys("noofTeam_Name", noofteamSearchData.substring(0, 1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void capacity() {
		try {
			String capacitySearchData = readExcel.read(1, 8);
			driver.findElement(By.name("CAPACITY")).clear();
			sendKeys("capacity_Name", capacitySearchData.substring(0, 1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void teamsDropDownBox() {
		try {
			String teamsSearchData = readExcel.read(1, 9);
			dropDown("teams_Name", teamsSearchData);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/*
	 * method for clicking save button
	 */
	public void saveButton() {
		try {
			getElement("save_Id").click();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for clicking return method
	 */
	public void Return() {
		try {
			getElement("Return_Id").click();
			//driver.switchTo().alert().accept();
			//Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for closing the browser
	 */
	public void close() {
		try {
			driver.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void switchFrame() {
		driver.switchTo().frame("content");
	}

	public void alertaccept() {
		driver.switchTo().alert().accept();
	}


}
