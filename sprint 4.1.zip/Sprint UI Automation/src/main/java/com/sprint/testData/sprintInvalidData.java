package com.sprint.testData;


import java.io.IOException;

import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.ReadExcel.readExcel;
import com.sprint.baseMethods;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class sprintInvalidData extends baseMethods
{
	
	
	public void invalidsprint() {
		try
    	{
			Select select=new Select(getElement("Sprint_Name"));
			select.selectByIndex(0);;
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
	}
	
	public void invalidStartDate() {
		getElement("StartDate_Name").clear();
	}
	
	public void invalidEndDate() {
		getElement("Date_Id").clear();
	}
	
	public void invalidRelease() {
		try {
			String releaseSearchData=readExcel.read(2,5);
			Select select=new Select(getElement("Release_Name"));
			select.selectByVisibleText(releaseSearchData);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void invalidnoofTeams() {
		getElement("noofTeam_Name").clear();
	}
	
	public void nameAssert() {
		String Actual = driver.switchTo().alert().getText().substring(78);
		String expected = "Name in Details tab";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	public void sprintAssert() {
		String Actual = driver.switchTo().alert().getText().substring(78);
		String expected = "Sprint Type in Details tab";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	public void startDateAssert() {
		String Actual = driver.switchTo().alert().getText().substring(78);
		String expected = "Start Date in Details tab";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	public void endDateAssert() {
		String Actual = driver.switchTo().alert().getText().substring(78);
		String expected = "End Date in Details tab";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	public void releaseAssert() {
		String Actual = driver.switchTo().alert().getText().substring(78);
		String expected = "Release in Details tab";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	public void noofteamsAssert() {
		String Actual = driver.switchTo().alert().getText().substring(78);
		String expected = "No. of Teams involved in Details tab";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	public void InvalidnoofteamsAssert() {
		String Actual = driver.switchTo().alert().getText();
		String expected = "Please do not enter decimal values in No. of Teams involved.";
		Assert.assertEquals(expected, Actual);
		System.out.println("Please enter the values and save: "+Actual);
		driver.switchTo().alert().accept();
		
	}
	
	
}