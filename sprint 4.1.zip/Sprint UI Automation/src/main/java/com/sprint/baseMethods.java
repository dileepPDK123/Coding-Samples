package com.sprint;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.ReadExcel.readExcel;
import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;

public class baseMethods {
	protected static WebDriver driver = null;
	public static Properties prop;
	public static String directory = System.getProperty("user.dir");

	/* ------------------------------ POM ------------------------------ */
	static By Hamburger = By.xpath("//div[@class='left_menu_icon_overlay']");
	static By project = By.xpath("//*[@id='projectIcon']/ul/li[1]/a");
	static By Plan = By.id("LOCK_Plan");
	static By Sprint = By.id("LOCK_Sprints");
	static By addBtn = By.id("KEY_BUTTON_Add-btnIconEl");
	static By StartDate = By.xpath("//*[@id='cal_STARTDATE']");
	static By MonthPOM = By.xpath("//*[@id='ui-datepicker-div']/div[1]/div/select[1]");
	static By YearPOM = By.xpath("//*[@id='ui-datepicker-div']/div[1]/div/select[2]");
	/* ------------------------------ POM ------------------------------ */

	/*
	 * method for opening browser
	 */
	public baseMethods() {

	}

	public baseMethods(WebDriver driver) {
		this.driver = driver;
	}

	public static void openBrowser() throws Exception {
		try {
			// open Browser
			// String
			// driverPath=System.getProperty("user.dir")+"\\Drivers\\chromedriver.exe";
			// System.setProperty("webdriver.chrome.driver", driverPath);
			// driver=new ChromeDriver();
			if (readExcel.read(5, 3).equalsIgnoreCase("Chrome")) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
			} else if (readExcel.read(5, 3).equalsIgnoreCase("Firefox")) {
				WebDriverManager.firefoxdriver().setup();
				FirefoxOptions fo = new FirefoxOptions();
				driver = new FirefoxDriver(fo);
			}
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			if (prop == null) {
				prop = new Properties();
				{
					// reading data from properties file
					FileInputStream file = new FileInputStream(
							directory + "\\src\\test\\resources\\ApplicationProperty\\configure.properties");
					prop.load(file);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for opening url
	 */
	public static void openURL(String url) {
		try {
			driver.get(readExcel.read(6, 3));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * method for opening defect page in the pratesting website
	 */
	public static void openSprint() throws Exception {
		/*
		 * Signin s=new Signin(); s.setDriver(driver); //u have to provide your login
		 * credentials in configure.properties file String
		 * user=prop.getProperty("username"); //String pwd=prop.getProperty("password");
		 * s.signIn(user);
		 */

		WebDriverWait wait = new WebDriverWait(driver, 1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(Hamburger));
		Actions action = new Actions(driver);
		WebElement leftmenu = driver.findElement(Hamburger);
		action.moveToElement(leftmenu).perform();

		// project name
		wait.until(ExpectedConditions.visibilityOfElementLocated(project));
		WebElement projectname = driver.findElement(project);
		projectname.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(180, TimeUnit.SECONDS);

		// click on plans
		
		Wait<WebDriver> wait1 = new FluentWait<WebDriver>(driver)							
		.withTimeout(30, TimeUnit.SECONDS) 			
		.pollingEvery(5, TimeUnit.SECONDS) 			
		.ignoring(NoSuchElementException.class);
		wait1.until(ExpectedConditions.visibilityOfElementLocated(Plan));
		WebElement monitor = driver.findElement(Plan);
		action.moveToElement(monitor).perform();

		// click sprints
		wait.until(ExpectedConditions.visibilityOfElementLocated(Sprint));
		driver.findElement(Sprint).click();

		// add key button
		wait.until(ExpectedConditions.visibilityOfElementLocated(addBtn));
		driver.findElement(addBtn).click();
	

	}

	/*
	 * Identifying The Element
	 */
	public static WebElement getElement(String locatorKey) {
		WebElement element = null;

		try {
			if (locatorKey.endsWith("_Id")) {
				element = driver.findElement(By.id(prop.getProperty(locatorKey)));
			} else if (locatorKey.endsWith("_Xpath")) {
				element = driver.findElement(By.xpath(prop.getProperty(locatorKey)));
			} else if (locatorKey.endsWith("_ClassName")) {
				element = driver.findElement(By.className(prop.getProperty(locatorKey)));
			} else if (locatorKey.endsWith("_CSS")) {
				element = driver.findElement(By.cssSelector(prop.getProperty(locatorKey)));
			} else if (locatorKey.endsWith("_LinkText")) {
				element = driver.findElement(By.linkText(prop.getProperty(locatorKey)));
			} else if (locatorKey.endsWith("_PartialLinkText")) {
				element = driver.findElement(By.partialLinkText(prop.getProperty(locatorKey)));
			} else if (locatorKey.endsWith("_Name")) {
				element = driver.findElement(By.name(prop.getProperty(locatorKey)));
			} else {
				System.out.println("Failing the Testcase, Invalid Locator " + locatorKey);
			}
		}

		catch (Exception e) {
			// Fail the TestCase and Report the error
			e.printStackTrace();
		}

		return element;
	}

	/*
	 * base Method for sendKeys
	 */
	public static void sendKeys(String locator, String ExcelValue) {
		try {
			WebElement n = getElement(locator);
			n.sendKeys(ExcelValue);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			String enteredname = n.getAttribute("value");
			System.out.println("Entered text is : " + enteredname);
			Assert.assertEquals(enteredname, ExcelValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * base method for selecting value of dropdown box
	 */
	public static void dropDown(String locator, String ExcelValue) {
		try {
			Select select = new Select(getElement(locator));
			select.selectByVisibleText(ExcelValue);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			String selectedText = select.getFirstSelectedOption().getText();
			Assert.assertEquals(selectedText, ExcelValue);
			System.out.println("selected item is:" + selectedText);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void start(String date) {
		// System.out.println("before frame");
		// driver.switchTo().frame("content");
		// System.out.println("after frame");
		WebElement button = driver.findElement(StartDate);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", button);
		System.out.println("after click");

		Date currentDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date expectedDate = dateFormat.parse(date);

			String day = new SimpleDateFormat("dd").format(expectedDate);
			String month = new SimpleDateFormat("MMMM").format(expectedDate);
			String year = new SimpleDateFormat("yyyy").format(expectedDate);

			Select Month = new Select(driver.findElement(MonthPOM));
			Month.selectByVisibleText(month);

			Select Year = new Select(driver.findElement(YearPOM));
			Year.selectByVisibleText(year);

			driver.findElement(By.xpath("//a[text()='" + day + "']")).click();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
